favoriteMoviesGenre("cowboy")

favoriteFruit("banana")

favoriteMode("dark")

favoriteEdgeStyle("round")